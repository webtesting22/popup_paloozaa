const scroll = new LocomotiveScroll({
    el: document.querySelector('.main-section'),
    smooth: true
});
